function alpha = normalize(element)
    alpha = (1/sum(element)).*element;
end
